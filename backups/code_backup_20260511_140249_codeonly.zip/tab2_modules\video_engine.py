import os
import random
import subprocess
import json
import shutil
import threading # [MỚI] IMPORT THƯ VIỆN KHÓA
import time
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
from shopee_export import export_rendered_video_to_shopee_files, is_shopee_out_of_stock_project
from paths import BASE_PATH, resource_path

# =======================================================
# [MỚI] TẠO Ổ KHÓA TOÀN CỤC BẢO VỆ FILE EXCEL (CSV)
# =======================================================
csv_write_lock = threading.Lock()
ffmpeg_heavy_render_lock = threading.Lock()

FFMPEG_FILTER_MEMORY_GUARD = ["-filter_threads", "1", "-filter_complex_threads", "1"]

SAFE_XFADE_TRANSITIONS = {
    'fade', 'slideleft', 'slideright', 'slideup', 'slidedown',
    'wipeleft', 'wiperight', 'hlslice', 'zoomin'
}


def _load_cover_font(custom_font, font_size):
    font_candidates = []
    if custom_font and os.path.exists(custom_font):
        font_candidates.append(custom_font)
    font_candidates.extend(["arial.ttf", "DejaVuSans-Bold.ttf"])

    for font_path in font_candidates:
        try:
            return ImageFont.truetype(font_path, font_size)
        except OSError:
            continue

    return ImageFont.load_default()


def _iter_cover_line_layouts(words, line_count):
    total_words = len(words)
    if line_count <= 1 or total_words <= 1:
        yield [" ".join(words)]
        return

    def _walk(start_index, lines_left, current_lines):
        remaining_words = total_words - start_index
        if lines_left == 1:
            current_lines.append(" ".join(words[start_index:]))
            yield list(current_lines)
            current_lines.pop()
            return

        max_chunk = remaining_words - (lines_left - 1)
        for take_count in range(1, max_chunk + 1):
            current_lines.append(" ".join(words[start_index:start_index + take_count]))
            yield from _walk(start_index + take_count, lines_left - 1, current_lines)
            current_lines.pop()

    yield from _walk(0, min(line_count, total_words), [])


def _fit_cover_layout(draw, layout_text, img_w, img_h, custom_font):
    max_text_width = img_w * 0.88
    max_text_height = img_h * 0.42
    low = 24
    
    # [BẢN ĐỘ MỚI] - KHÓA CỨNG KÍCH THƯỚC CHỮ TỐI ĐA (GOLDEN SIZE)
    # Thay vì cho nó phóng to đến int(img_h * 0.16) (rất khổng lồ), 
    # Ta chốt nó ở mức int(img_w * 0.13) (khoảng 140px cho video 1080p).
    # Chữ ngắn sẽ dừng ở mức này, chữ dài sẽ tự động scale nhỏ lại một chút.
    golden_max_size = int(img_w * 0.13) 
    high = max(low, golden_max_size)
    
    best_fit = None

    while low <= high:
        font_size = (low + high) // 2
        font = _load_cover_font(custom_font, font_size)
        stroke_w = max(2, int(font_size * 0.11))
        line_spacing = max(6, int(font_size * 0.08))
        
        bbox = draw.multiline_textbbox(
            (0, 0), layout_text, font=font, align="center",
            spacing=line_spacing, stroke_width=stroke_w,
        )
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]

        if text_width <= max_text_width and text_height <= max_text_height:
            best_fit = (font_size, font, stroke_w, line_spacing, text_width, text_height)
            low = font_size + 1
        else:
            high = font_size - 1

    return best_fit


def _choose_cover_layout(draw, source_text, img_w, img_h, custom_font):
    words = source_text.split()
    if not words:
        font = _load_cover_font(custom_font, 72)
        return source_text, font, 8, 8

    if len(words) <= 2:
        max_lines = 1
    elif len(words) <= 6:
        max_lines = 2
    elif len(words) <= 10:
        max_lines = 3
    else:
        max_lines = 4

    best_layout = None
    seen_layouts = set()

    for line_count in range(1, min(max_lines, len(words)) + 1):
        for lines in _iter_cover_line_layouts(words, line_count):
            layout_text = "\n".join(lines)
            if layout_text in seen_layouts:
                continue
            seen_layouts.add(layout_text)

            fit = _fit_cover_layout(draw, layout_text, img_w, img_h, custom_font)
            if not fit:
                continue

            font_size, font, stroke_w, line_spacing, text_width, _ = fit
            line_lengths = [len(line) for line in lines if line.strip()]
            balance_score = max(line_lengths) - min(line_lengths) if len(line_lengths) > 1 else 0
            candidate = (
                font_size,
                -balance_score,
                -len(lines),
                -(text_width / max(img_w, 1)),
                layout_text,
                font,
                stroke_w,
                line_spacing,
            )

            if best_layout is None or candidate > best_layout:
                best_layout = candidate

    if best_layout is not None:
        return best_layout[4], best_layout[5], best_layout[6], best_layout[7]

    fallback_font = _load_cover_font(custom_font, 24)
    return source_text, fallback_font, 3, 6


def add_cover_to_existing_video(input_video, out_file, cover_text, custom_font="", log_cb=None):
    """Gắn ảnh bìa đầu video ngoài bằng cùng logic bìa đang dùng khi render Tab 2."""
    def log(message):
        if log_cb:
            log_cb(message)

    if not os.path.exists(input_video):
        raise FileNotFoundError(input_video)

    out_dir = os.path.dirname(out_file) or os.getcwd()
    os.makedirs(out_dir, exist_ok=True)
    creation_flags = 0x08000000 if os.name == "nt" else 0
    safe_stem = os.path.splitext(os.path.basename(input_video))[0]
    temp_token = f"external_{safe_stem}_{int(time.time() * 1000)}_{threading.get_ident()}"
    temp_frame_jpg = os.path.join(out_dir, f"temp_frame_{temp_token}.jpg")
    temp_cover_png = os.path.join(out_dir, f"temp_cover_{temp_token}.png")

    frame_ready = False
    frame_error = ""
    for point in [1.0, 0.5, 0.0]:
        frame_result = subprocess.run(
            ["ffmpeg", "-y", "-ss", f"{point:.2f}", "-i", input_video, "-frames:v", "1", "-q:v", "2", temp_frame_jpg],
            capture_output=True, text=True, encoding="utf-8", errors="ignore", creationflags=creation_flags,
        )
        if frame_result.returncode == 0 and os.path.exists(temp_frame_jpg) and os.path.getsize(temp_frame_jpg) > 0:
            frame_ready = True
            break
        frame_error = (frame_result.stderr or frame_result.stdout or "Không rõ lỗi")[-400:]

    clean_cover_text = " ".join(str(cover_text or safe_stem).replace("_", " ").split()).upper()
    try:
        if frame_ready:
            with Image.open(temp_frame_jpg).convert("RGBA") as img:
                draw = ImageDraw.Draw(img)
                img_w, img_h = img.size
                display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_cover_text, img_w, img_h, custom_font)
                draw.multiline_text(
                    (img_w / 2, img_h / 2),
                    display_text,
                    font=font,
                    fill="white",
                    align="center",
                    anchor="mm",
                    spacing=line_spacing,
                    stroke_width=stroke_w,
                    stroke_fill="black",
                )
                img.convert("RGB").save(temp_cover_png)
        else:
            img = Image.new("RGBA", (1080, 1920), (22, 28, 36, 255))
            draw = ImageDraw.Draw(img)
            display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_cover_text, 1080, 1920, custom_font)
            draw.multiline_text(
                (540, 960),
                display_text,
                font=font,
                fill="white",
                align="center",
                anchor="mm",
                spacing=line_spacing,
                stroke_width=stroke_w,
                stroke_fill="black",
            )
            img.convert("RGB").save(temp_cover_png)
            log(f"⚠️ Không trích được frame làm bìa, dùng bìa nền dự phòng. {frame_error[:120]}")

        ffmpeg_concat_cmd = [
            "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", input_video,
            "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a?",
            "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k", "-c:a", "copy", out_file,
        ]
        concat_result = subprocess.run(ffmpeg_concat_cmd, capture_output=True, text=True, errors="ignore", creationflags=creation_flags)
        final_ready = concat_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0

        if not final_ready:
            ffmpeg_concat_fallback_cmd = [
                "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", input_video,
                "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a?",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", out_file,
            ]
            fallback_result = subprocess.run(ffmpeg_concat_fallback_cmd, capture_output=True, text=True, errors="ignore", creationflags=creation_flags)
            final_ready = fallback_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0
            if final_ready:
                log("⚠️ NVENC gắn bìa lỗi, đã fallback sang libx264 thành công.")

        if not final_ready:
            raise Exception("Không gắn được ảnh bìa vào video ngoài.")
        return out_file
    finally:
        for f_path in [temp_frame_jpg, temp_cover_png]:
            if os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except Exception:
                    pass


def _resolve_media_asset(*file_names):
    candidates = []
    for file_name in file_names:
        candidates.extend([
            resource_path(file_name),
            os.path.join(BASE_PATH, file_name),
            os.path.join(os.getcwd(), file_name),
        ])

    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate

    return ""

def get_vid_info(file_path):
    """Lấy độ dài và kiểm tra xem video có chứa rãnh Audio hay không"""
    try:
        cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type', '-of', 'json', file_path]
        out = subprocess.check_output(cmd, creationflags=0x08000000 if os.name == 'nt' else 0)
        data = json.loads(out)
        dur = float(data.get('format', {}).get('duration', 5.0))
        has_audio = any(s.get('codec_type') == 'audio' for s in data.get('streams', []))
        return dur, has_audio
    except:
        return 5.0, False


def _build_atempo_chain(speed):
    if speed <= 0:
        return "atempo=1.0"

    factors = []
    remaining = float(speed)

    while remaining > 2.0:
        factors.append(2.0)
        remaining /= 2.0

    while remaining < 0.5:
        factors.append(0.5)
        remaining /= 0.5

    factors.append(remaining)
    return ",".join(f"atempo={f:.3f}" for f in factors)


def apply_video_speed_after_render(video_path, speed, log_cb):
    try:
        speed = float(speed)
    except Exception:
        speed = 1.0

    if abs(speed - 1.0) < 0.001:
        return video_path

    if not os.path.exists(video_path):
        raise Exception(f"Không tìm thấy video để tăng tốc: {video_path}")

    log_cb(f"[PostRender] Tăng tốc video tổng x{speed:.2f}...")

    out_dir = os.path.dirname(video_path)
    base_name = os.path.splitext(os.path.basename(video_path))[0]
    temp_path = os.path.join(out_dir, f"{base_name}_speed_{int(time.time() * 1000)}.mp4")
    creation_flags = 0x08000000 if os.name == 'nt' else 0

    _, has_audio = get_vid_info(video_path)
    v_filter = f"setpts=PTS/{speed:.6f}"

    if has_audio:
        a_filter = _build_atempo_chain(speed)
        filter_complex = f"[0:v]{v_filter}[v];[0:a]{a_filter}[a]"
        ffmpeg_cmd = [
            "ffmpeg", "-y", "-i", video_path,
            "-filter_complex", filter_complex,
            "-map", "[v]", "-map", "[a]",
            "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k",
            "-c:a", "aac", "-b:a", "192k",
            "-shortest", temp_path,
        ]
    else:
        ffmpeg_cmd = [
            "ffmpeg", "-y", "-i", video_path,
            "-filter:v", v_filter,
            "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k",
            "-an", temp_path,
        ]

    result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", creationflags=creation_flags)
    if result.returncode != 0:
        fallback_cmd = [
            "ffmpeg", "-y", "-i", video_path,
            "-filter:v", v_filter,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        ]
        if has_audio:
            fallback_cmd += ["-filter:a", _build_atempo_chain(speed), "-c:a", "aac", "-b:a", "192k", "-shortest"]
        else:
            fallback_cmd += ["-an"]
        fallback_cmd.append(temp_path)
        result = subprocess.run(fallback_cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", creationflags=creation_flags)

    if result.returncode != 0 or not os.path.exists(temp_path) or os.path.getsize(temp_path) == 0:
        raise Exception(f"Lỗi tăng tốc video: {(result.stderr or result.stdout or '')[-1200:]}")

    os.replace(temp_path, video_path)
    return video_path

# [BẢN ĐỘ MỚI - FIX LỖI HỤT VIDEO] 
def render_faceless_video(voice_name, voice_path, timeline, proj_dir, proj_name, config, out_file, out_dir, log_cb, broll_data=None):
    used_brolls = []
    
    # ❌ ĐÃ BỎ speed_val vì nó là thủ phạm làm video bị ngắn hơn Voice
    auto_speed_max = config.get("auto_speed_max", 1.4)
    bright_val = config.get("video_bright", 1.0)
    use_trans = config.get("use_trans", True)
    use_sfx = config.get("use_sfx", True)
    broll_vol = config.get("broll_vol", 30) / 100.0 
    custom_font = config.get("font_path", "")
    whoosh_sfx_path = _resolve_media_asset("whoosh.mp3", "whoosh.MP3")
    
    trans_dur = config.get("trans_duration", 0.5)
    log_cb(f"[{voice_name}] Đang phân tích Timeline & Gắn hiệu ứng (Fix lỗi hụt video)...")
    
    voice_dur, _ = get_vid_info(voice_path)
    
    all_brolls = [f for f in os.listdir(os.path.join(proj_dir, "Broll")) if f.lower().endswith(('.mp4', '.mov'))]
    if not all_brolls: raise Exception("Không tìm thấy video Broll nào trong project!")

    if not timeline:
        log_cb(f"[{voice_name}] ⚠️ Timeline AI rỗng! Tự động lấp đầy toàn dải...")
        timeline = [{"video_file": "", "start": 0, "end": voice_dur}]

    global_used_vids = set()
    vid_offsets = {} 
    last_vid_name = None
    selected_clips = []
    current_time = 0.0

    for i, row in enumerate(timeline):
        end_time = float(row.get("end", 0))
        if i == len(timeline) - 1: end_time = max(end_time, voice_dur)
        req_duration = end_time - current_time
        if req_duration <= 0: continue

        actual_req_dur = max(req_duration, 1.0) 
        if i == 1 and use_trans: actual_req_dur += trans_dur

        current_dur = 0.0
        fail_safe = 0
        scene_vids = []
        
        ai_chosen_videos = row.get("video_files", [])
        if isinstance(ai_chosen_videos, str): ai_chosen_videos = [ai_chosen_videos] 
        
        ai_queue = [v for v in ai_chosen_videos if os.path.exists(os.path.join(proj_dir, "Broll", v))]

        while current_dur < actual_req_dur and fail_safe < 200:
            if ai_queue:
                v_n = ai_queue.pop(0)
            else:
                available = [f for f in all_brolls if f not in global_used_vids]
                if not available: 
                    global_used_vids.clear()
                    available = all_brolls
                if len(available) > 1 and last_vid_name in available: available.remove(last_vid_name)
                
                available.sort(key=lambda v: broll_data.get(v, {}).get('usage_count', 0))
                top_candidates = available[:3] 
                v_n = random.choice(top_candidates)
            
            v_path = os.path.join(proj_dir, "Broll", v_n)
            dur, has_audio = get_vid_info(v_path)
            
            start_t = vid_offsets.get(v_n, 0.0)
            avail_dur = dur - start_t
            
            if avail_dur < 1.0:
                start_t = 0.0
                avail_dur = dur

            rem = actual_req_dur - current_dur

            if avail_dur >= rem:
                spd = avail_dur / rem
                if spd > auto_speed_max:
                    spd = auto_speed_max
                    consume_dur = rem * auto_speed_max
                else:
                    consume_dur = avail_dur
                
                scene_vids.append({'path': v_path, 'name': v_n, 'start_t': start_t, 'trim': consume_dur, 'speed': spd, 'has_audio': has_audio})
                current_dur += rem
                vid_offsets[v_n] = start_t + consume_dur
                
            else:
                missing_dur = rem - avail_dur
                needed_speed = avail_dur / rem
                if missing_dur < 1.0 and needed_speed >= 0.95:
                    scene_vids.append({'path': v_path, 'name': v_n, 'start_t': start_t, 'trim': avail_dur, 'speed': needed_speed, 'has_audio': has_audio})
                    current_dur += rem
                else:
                    scene_vids.append({'path': v_path, 'name': v_n, 'start_t': start_t, 'trim': avail_dur, 'speed': 1.0, 'has_audio': has_audio})
                    current_dur += avail_dur
                    
                vid_offsets[v_n] = start_t + avail_dur

            global_used_vids.add(v_n)
            last_vid_name = v_n
            fail_safe += 1

        if scene_vids:
            # ✅ FIX 1: Tính chuẩn thời gian thực tế, không dùng speed_val gây hụt time
            scene_real_dur = sum(
                clip['trim'] / max(clip['speed'], 0.01)
                for clip in scene_vids
            )
            selected_clips.append({'vids': scene_vids, 'dur': scene_real_dur})
        current_time = end_time

    if not selected_clips:
        raise Exception("❌ File Voice quá ngắn hoặc thuật toán không gắp được cảnh nào.")

    log_cb(f"[{voice_name}] Đang căn chỉnh ma trận Audio & Hình ảnh...")
    inputs = []
    v_filters = []
    vid_input_idx = 0
    pre_labels = []
    broll_audio_labels = []
    
    abs_time = 0.0
    next_abs_time = 0.0

    for i, scene in enumerate(selected_clips):
        scene_input_vids = []
        
        if i == 0:
            abs_time = 0.0
            next_abs_time = scene['dur']
        elif i == 1 and use_trans:
            abs_time = selected_clips[0]['dur'] - trans_dur
            next_abs_time = abs_time + scene['dur']
        else:
            abs_time = next_abs_time
            next_abs_time = abs_time + scene['dur']

        clip_time = abs_time

        for j, clip in enumerate(scene['vids']):
            inputs.extend(['-i', clip['path']])
            
            end_t = clip['start_t'] + clip['trim']
            
            # ✅ FIX 2: Bỏ speed_val để hình ảnh không chạy quá nhanh làm lòi đuôi Voice
            pts_mod = 1.0 / clip['speed']
            
            flt_v = (
                f"[{vid_input_idx}:v]trim={clip['start_t']:.3f}:{end_t:.3f},setpts={pts_mod}*(PTS-STARTPTS),"
                f"lutyuv=y=val*{bright_val},"
                f"scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,"
                f"fps=30,format=yuv420p,setsar=1,eq=contrast=1.0[v_tmp{vid_input_idx}]"
            )
            v_filters.append(flt_v)
            scene_input_vids.append(f"[v_tmp{vid_input_idx}]")
            
            keep_audio = broll_data.get(clip['name'], {}).get('keep_audio', False)
            if keep_audio and clip['has_audio'] and broll_vol > 0:
                # ✅ FIX 3: Đồng bộ audio phụ theo đúng tốc độ mới
                speed_factor = clip['speed']
                delay_ms = int(clip_time * 1000)
                atempo_str = f"{_build_atempo_chain(speed_factor)}," if speed_factor != 1.0 else ""
                
                flt_a = (
                    f"[{vid_input_idx}:a]atrim={clip['start_t']:.3f}:{end_t:.3f},asetpts=PTS-STARTPTS,"
                    f"{atempo_str}aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,"
                    f"volume={broll_vol},adelay={delay_ms}|{delay_ms}[baud_{vid_input_idx}]"
                )
                v_filters.append(flt_a)
                broll_audio_labels.append(f"[baud_{vid_input_idx}]")

            clip_time += clip['trim'] * pts_mod
            vid_input_idx += 1

        if len(scene_input_vids) > 1:
            raw_scene_label = f"[scenev_raw{i}]"
            scene_label = f"[scenev{i}]"
            concat_sc_flt = "".join(scene_input_vids) + f"concat=n={len(scene_input_vids)}:v=1:a=0{raw_scene_label}"
            v_filters.append(concat_sc_flt)
            v_filters.append(f"{raw_scene_label}settb=AVTB,setpts=PTS-STARTPTS,fps=30{scene_label}")
            pre_labels.append(scene_label)
        elif len(scene_input_vids) == 1:
            scene_label = f"[scenev{i}]"
            v_filters.append(f"{scene_input_vids[0]}settb=AVTB,setpts=PTS-STARTPTS,fps=30{scene_label}")
            pre_labels.append(scene_label)

    inputs.extend(['-i', voice_path])
    voice_idx = vid_input_idx 
    chosen_trans = None
    flt_fade = None
    xfade_fallback_flt = None

    if len(pre_labels) > 1 and use_trans:
        sc_dur = selected_clips[0]['dur']
        
        safe_trans_dur = min(trans_dur, sc_dur - 0.2) 
        if safe_trans_dur <= 0: safe_trans_dur = 0.2
        
        fade_offset = max(0.0, sc_dur - safe_trans_dur)
        label_fade = "[vfade0]"
        
        trans_mapping = {
            "fade": "fade", "slide_left": "slideleft", "slide_right": "slideright",
            "slide_up": "slideup", "slide_down": "slidedown", "wipe_left": "wipeleft",
            "wipe_right": "wiperight", "hlslice": "hlslice", "vsplit": "vsplit",
            "zoom_in": "zoomin", "zoom_out": "zoomout", "diagonal": "diagonal", "cross_fade": "fade",
        }
        
        selected_trans_keys = config.get("selected_transitions", ["fade"])
        available_trans = [trans_mapping[t] for t in selected_trans_keys if t in trans_mapping and trans_mapping[t] in SAFE_XFADE_TRANSITIONS]
        if not available_trans: available_trans = ['fade']
        
        chosen_trans = random.choice(available_trans)
        if chosen_trans not in SAFE_XFADE_TRANSITIONS:
            chosen_trans = 'fade'
        
        # ✅ FIX 4: Thay đổi 'duration={trans_dur}' thành 'duration={safe_trans_dur}' chống crash Xfade
        flt_fade = f"{pre_labels[0]}{pre_labels[1]}xfade=transition={chosen_trans}:duration={safe_trans_dur}:offset={fade_offset},settb=AVTB,setpts=PTS-STARTPTS{label_fade}"
        xfade_fallback_flt = f"{pre_labels[0]}{pre_labels[1]}concat=n=2:v=1:a=0,settb=AVTB,setpts=PTS-STARTPTS{label_fade}"
        v_filters.append(flt_fade)
        
        concat_inputs = [label_fade] + pre_labels[2:]
        if len(concat_inputs) > 1:
            v_filters.append(f"{''.join(concat_inputs)}concat=n={len(concat_inputs)}:v=1:a=0,settb=AVTB,setpts=PTS-STARTPTS[outv]")
            outv_map = "[outv]"
        else:
            outv_map = label_fade
    elif len(pre_labels) > 1:
        v_filters.append(f"{''.join(pre_labels)}concat=n={len(pre_labels)}:v=1:a=0,settb=AVTB,setpts=PTS-STARTPTS[outv]")
        outv_map = "[outv]"
        fade_offset = 0
    elif len(pre_labels) == 1:
        outv_map = pre_labels[0]
        fade_offset = 0
    else:
        raise Exception("❌ Cảnh báo FFmpeg: Không có khung hình nào để render!")

    v_filters.append(f"[{voice_idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[norm_voice]")
    mix_audio_inputs = ["[norm_voice]"] 
    
    if use_trans and use_sfx and os.path.exists(whoosh_sfx_path) and fade_offset > 0:
        inputs.extend(['-i', whoosh_sfx_path])
        sfx_idx = voice_idx + 1 
        
        v_filters.append(
            f"[{sfx_idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,"
            f"adelay={int(fade_offset * 1000)}|{int(fade_offset * 1000)}[sfx0]"
        )
        mix_audio_inputs.append("[sfx0]")

    mix_audio_inputs.extend(broll_audio_labels)

    num_mix = len(mix_audio_inputs)
    if num_mix > 1:
        mix_str = "".join(mix_audio_inputs)
        mix_flt = f"{mix_str}amix=inputs={num_mix}:duration=first:dropout_transition=0:normalize=0[outa]"
        v_filters.append(mix_flt)
        a_mix_final_map = "[outa]"
    else:
        a_mix_final_map = mix_audio_inputs[0]

    filter_complex = ";\n".join(v_filters)
    filter_script_path = os.path.join(out_dir, f"filter_{os.path.splitext(voice_name)[0]}.txt")
    with open(filter_script_path, 'w', encoding='utf-8') as f: f.write(filter_complex)

    creation_flags = 0x08000000 if os.name == 'nt' else 0
    temp_main_mp4 = os.path.join(out_dir, f"temp_main_{os.path.splitext(voice_name)[0]}.mp4")

    log_cb(f"[{voice_name}] Đang xuất xưởng bằng NVENC siêu tốc...")
    ffmpeg_cmd = [
        'ffmpeg', '-y'
    ] + inputs + [
        *FFMPEG_FILTER_MEMORY_GUARD,
        '-filter_complex_script', filter_script_path,
        '-map', outv_map,
        '-map', a_mix_final_map,
        '-c:v', 'h264_nvenc', '-preset', 'p1', '-b:v', '8000k',
        '-c:a', 'aac', '-b:a', '192k',
        '-shortest',
        temp_main_mp4
    ]

    with ffmpeg_heavy_render_lock:
        process = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore', creationflags=creation_flags)
    if process.returncode != 0 and chosen_trans and ("Not yet implemented in FFmpeg" in process.stderr or "Error applying option 'transition'" in process.stderr):
        fallback_filter_complex = filter_complex.replace(f"transition={chosen_trans}", "transition=fade", 1)
        with open(filter_script_path, 'w', encoding='utf-8') as f: f.write(fallback_filter_complex)
        with ffmpeg_heavy_render_lock:
            process = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore', creationflags=creation_flags)
    if process.returncode != 0 and flt_fade and xfade_fallback_flt and ("Parsed_xfade" in process.stderr or "do not match" in process.stderr or "Failed to configure output pad" in process.stderr or "Cannot allocate memory" in process.stderr):
        if "Cannot allocate memory" in process.stderr:
            log_cb(f"[{voice_name}] ⚠️ FFmpeg thiếu RAM khi chuyển cảnh, render lại không dùng xfade...")
        fallback_filter_complex = filter_complex.replace(flt_fade, xfade_fallback_flt, 1)
        with open(filter_script_path, 'w', encoding='utf-8') as f: f.write(fallback_filter_complex)
        with ffmpeg_heavy_render_lock:
            process = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore', creationflags=creation_flags)

    if process.returncode != 0: raise Exception(f"Lỗi FFmpeg: {process.stderr[-1500:]}")

    safe_stem = os.path.splitext(voice_name)[0]
    temp_token = f"{safe_stem}_{int(time.time() * 1000)}_{threading.get_ident()}"
    temp_frame_jpg = os.path.join(out_dir, f"temp_frame_{temp_token}.jpg")
    temp_cover_png = os.path.join(out_dir, f"temp_cover_{temp_token}.png")

    if not config.get("enable_cover", True):
        shutil.copy2(temp_main_mp4, out_file)
        if not (os.path.exists(out_file) and os.path.getsize(out_file) > 0):
            raise Exception(f"Không lưu được video đầu ra cho {voice_name}")
        log_cb(f"[{voice_name}] ⏭️ Tài khoản này tắt làm ảnh bìa, xuất video không gắn bìa.")
        for f_path in [filter_script_path, temp_main_mp4, temp_frame_jpg, temp_cover_png]:
            if os.path.exists(f_path):
                try: os.remove(f_path)
                except: pass
        shopee_out_of_stock = is_shopee_out_of_stock_project(proj_dir)
        from shopee_export import export_rendered_video_to_shopee_files
        exported_to_shopee, _ = export_rendered_video_to_shopee_files(proj_dir, out_file, config=config, default_status="Chưa đăng")
        if shopee_out_of_stock: log_cb(f"[{voice_name}] ⏭️ Shopee Hết hàng, bỏ qua lưu Job.")
        elif exported_to_shopee: log_cb(f"[{voice_name}] ✅ Đã lưu Job Shopee thành công!")
        return list(global_used_vids)

    extract_points = []
    if voice_dur > 2.0:
        random_sec = round(random.uniform(1.0, voice_dur - 1.0), 2)
        extract_points = [random_sec, round(voice_dur / 2, 2), 0.5] 
    else:
        extract_points = [0.0]

    frame_ready = False
    frame_error = ""
    for point in extract_points:
        frame_result = subprocess.run(
        ['ffmpeg', '-y', '-ss', f"{point:.2f}", '-i', temp_main_mp4, '-frames:v', '1', '-q:v', '2', temp_frame_jpg],
            capture_output=True, text=True, encoding='utf-8', errors='ignore', creationflags=creation_flags,
        )
        if frame_result.returncode == 0 and os.path.exists(temp_frame_jpg) and os.path.getsize(temp_frame_jpg) > 0:
            frame_ready = True
            break
        frame_error = (frame_result.stderr or frame_result.stdout or "Không rõ lỗi")[-400:]

    # Nếu không trích được frame thì vẫn tạo bìa nền trơn để không bỏ sót cover.
    if not frame_ready:
        try:
            img = Image.new("RGBA", (1080, 1920), (22, 28, 36, 255))
            draw = ImageDraw.Draw(img)
            clean_proj_name = " ".join(proj_name.replace("_", " ").split()).upper()
            display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_proj_name, 1080, 1920, custom_font)
            draw.multiline_text(
                (540, 960),
                display_text,
                font=font,
                fill="white",
                align="center",
                anchor="mm",
                spacing=line_spacing,
                stroke_width=stroke_w,
                stroke_fill="black",
            )
            img.convert("RGB").save(temp_cover_png)
            frame_ready = True
            log_cb(f"[{voice_name}] ⚠️ Không trích được frame làm bìa, dùng bìa nền dự phòng. {frame_error[:120]}")
        except Exception as e:
            frame_error = str(e)

    final_video_ready = False
    if frame_ready:
        try:
            # Nếu đã có frame thật thì vẽ text lên frame, nếu không thì dùng file cover dự phòng vừa tạo.
            if os.path.exists(temp_frame_jpg) and os.path.getsize(temp_frame_jpg) > 0:
                with Image.open(temp_frame_jpg).convert("RGBA") as img:
                    draw = ImageDraw.Draw(img)
                    img_w, img_h = img.size
                    clean_proj_name = " ".join(proj_name.replace("_", " ").split()).upper()
                    display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_proj_name, img_w, img_h, custom_font)
                    draw.multiline_text((img_w / 2, img_h / 2), display_text, font=font, fill="white", align="center", anchor="mm", spacing=line_spacing, stroke_width=stroke_w, stroke_fill="black")
                    img.convert("RGB").save(temp_cover_png)

            ffmpeg_concat_cmd = [
                "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", temp_main_mp4,
                "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a",
                "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k", "-c:a", "copy", out_file
            ]
            concat_result = subprocess.run(ffmpeg_concat_cmd, capture_output=True, text=True, errors='ignore', creationflags=creation_flags)
            final_video_ready = concat_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0

            # Fallback khi NVENC concat lỗi (thường gặp ở máy thiếu tài nguyên GPU).
            if not final_video_ready:
                ffmpeg_concat_fallback_cmd = [
                    "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", temp_main_mp4,
                    "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", out_file
                ]
                concat_fallback_result = subprocess.run(ffmpeg_concat_fallback_cmd, capture_output=True, text=True, errors='ignore', creationflags=creation_flags)
                final_video_ready = concat_fallback_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0
                if final_video_ready:
                    log_cb(f"[{voice_name}] ⚠️ NVENC gắn bìa lỗi, đã fallback sang libx264 thành công.")
        except Exception: pass

    if not final_video_ready:
        log_cb(f"[{voice_name}] ⚠️ Không gắn được bìa, xuất video gốc không bìa. {frame_error[:120]}")
        shutil.copy2(temp_main_mp4, out_file)
        final_video_ready = os.path.exists(out_file) and os.path.getsize(out_file) > 0

    if not final_video_ready:
        raise Exception(f"Không lưu được video đầu ra cho {voice_name}")

    for f_path in [filter_script_path, temp_main_mp4, temp_frame_jpg, temp_cover_png]:
        if os.path.exists(f_path):
            try: os.remove(f_path)
            except: pass

    shopee_out_of_stock = is_shopee_out_of_stock_project(proj_dir)
    from shopee_export import export_rendered_video_to_shopee_files
    exported_to_shopee, _ = export_rendered_video_to_shopee_files(proj_dir, out_file, config=config, default_status="Chưa đăng")
    
    if shopee_out_of_stock: log_cb(f"[{voice_name}] ⏭️ Shopee Hết hàng, bỏ qua lưu Job.")
    elif exported_to_shopee: log_cb(f"[{voice_name}] ✅ Đã lưu Job Shopee thành công!")
        
    return list(global_used_vids)


def render_faceless_video_with_base(voice_name, voice_path, timeline, proj_dir, proj_name, config, out_file, out_dir, log_cb, broll_data=None):
    used_brolls = []

    bright_val = config.get("video_bright", 1.0)
    broll_vol = config.get("broll_vol", 30) / 100.0
    custom_font = config.get("font_path", "")

    voice_dur, voice_has_audio = get_vid_info(voice_path)

    all_brolls = [f for f in os.listdir(os.path.join(proj_dir, "Broll")) if f.lower().endswith((".mp4", ".mov"))]
    if not all_brolls:
        raise Exception("Không tìm thấy video Broll nào trong project!")

    def pick_loose_broll():
        candidates = sorted(all_brolls, key=lambda v: broll_data.get(v, {}).get("usage_count", 0))
        top = candidates[:5] if len(candidates) > 5 else candidates
        return random.choice(top) if top else random.choice(all_brolls)

    segments = []
    timeline = timeline or []
    timeline_sorted = sorted(timeline, key=lambda item: float(item.get("start", 0.0) or 0.0))

    first_overlay_done = False
    for row in timeline_sorted:
        start = float(row.get("start", 0.0) or 0.0)
        end = float(row.get("end", 0.0) or 0.0)
        if end <= start:
            continue

        candidates = row.get("video_files", []) or row.get("video_file", []) or []
        if isinstance(candidates, str):
            candidates = [candidates]
        candidates = [c for c in candidates if os.path.exists(os.path.join(proj_dir, "Broll", c))]

        if not candidates and first_overlay_done:
            continue

        broll_name = candidates[0] if candidates else pick_loose_broll()
        broll_path = os.path.join(proj_dir, "Broll", broll_name)
        clip_dur, clip_has_audio = get_vid_info(broll_path)
        if clip_dur <= 0:
            continue

        if not first_overlay_done:
            start = 0.0

        seg_dur = max(0.0, end - start)
        if seg_dur <= 0:
            continue

        overlay_dur = min(seg_dur, clip_dur)
        if not first_overlay_done and overlay_dur < 1.0:
            overlay_dur = min(1.0, clip_dur)

        segments.append({
            "path": broll_path,
            "name": broll_name,
            "start": start,
            "dur": overlay_dur,
            "has_audio": clip_has_audio,
        })
        used_brolls.append(broll_name)
        first_overlay_done = True

    if not segments:
        broll_name = pick_loose_broll()
        broll_path = os.path.join(proj_dir, "Broll", broll_name)
        clip_dur, clip_has_audio = get_vid_info(broll_path)
        overlay_dur = min(2.0, clip_dur) if clip_dur > 0 else 1.0
        segments.append({
            "path": broll_path,
            "name": broll_name,
            "start": 0.0,
            "dur": overlay_dur,
            "has_audio": clip_has_audio,
        })
        used_brolls.append(broll_name)

    # Giữ tỷ lệ broll/base theo config (mặc định 50/50)
    ratio = config.get("base_broll_ratio", 0.5)
    try:
        ratio = float(ratio)
    except Exception:
        ratio = 0.5
    ratio = max(0.0, min(1.0, ratio))

    target_broll_dur = voice_dur * ratio
    if target_broll_dur > 0 and segments:
        trimmed = []
        remaining = target_broll_dur
        for seg in segments:
            if remaining <= 0:
                break
            seg_dur = max(0.0, float(seg.get("dur", 0.0)))
            if seg_dur <= 0:
                continue
            use_dur = min(seg_dur, remaining)
            trimmed.append({**seg, "dur": use_dur})
            remaining -= use_dur
        if trimmed:
            segments = trimmed

        # Rải cảnh trám đều theo timeline (giữ cảnh đầu ở đầu video).
        if segments:
            first = segments[0]
            first["start"] = 0.0
            remaining_segments = segments[1:]
            if remaining_segments and voice_dur > 0:
                base_start = max(0.0, float(first.get("dur", 0.0)))
                available = max(0.0, voice_dur - base_start)
                step = available / (len(remaining_segments) + 1)
                last_end = base_start
                min_gap = 0.2
                for idx, seg in enumerate(remaining_segments, 1):
                    seg_dur = max(0.0, float(seg.get("dur", 0.0)))
                    if seg_dur <= 0:
                        seg["start"] = last_end
                        continue
                    desired = base_start + step * idx - (seg_dur / 2.0)
                    start = max(0.0, min(desired, max(0.0, voice_dur - seg_dur)))
                    if start < last_end + min_gap:
                        start = min(last_end + min_gap, max(0.0, voice_dur - seg_dur))
                    seg["start"] = start
                    last_end = start + seg_dur

    inputs = ["-i", voice_path]
    v_filters = []
    a_filters = []
    overlay_chain = "[basev]"

    v_filters.append(
        "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,"
        f"lutyuv=y=val*{bright_val},fps=30,format=yuv420p,setsar=1[basev]"
    )

    audio_inputs = []
    if voice_has_audio:
        a_filters.append("[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[basea]")
        audio_inputs.append("[basea]")

    for idx, seg in enumerate(segments, 1):
        inputs.extend(["-i", seg["path"]])
        start_t = 0.0
        end_t = seg["dur"]
        v_filters.append(
            f"[{idx}:v]trim={start_t:.3f}:{end_t:.3f},setpts=PTS-STARTPTS+{seg['start']:.3f}/TB,"
            "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,"
            f"fps=30,format=yuva420p[ovv{idx}]"
        )
        v_filters.append(
            f"{overlay_chain}[ovv{idx}]overlay=0:0:eof_action=pass[v{idx}]"
        )
        overlay_chain = f"[v{idx}]"

        keep_audio = broll_data.get(seg["name"], {}).get("keep_audio", False)
        if keep_audio and seg["has_audio"] and broll_vol > 0:
            delay_ms = int(seg["start"] * 1000)
            a_filters.append(
                f"[{idx}:a]atrim={start_t:.3f}:{end_t:.3f},asetpts=PTS-STARTPTS,"
                f"aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,volume={broll_vol},"
                f"adelay={delay_ms}|{delay_ms}[ba{idx}]"
            )
            audio_inputs.append(f"[ba{idx}]")

    outv_map = overlay_chain

    if audio_inputs:
        if len(audio_inputs) > 1:
            mix_flt = f"{''.join(audio_inputs)}amix=inputs={len(audio_inputs)}:duration=first:dropout_transition=0:normalize=0[outa]"
            a_filters.append(mix_flt)
            outa_map = "[outa]"
        else:
            outa_map = audio_inputs[0]
    else:
        outa_map = None

    filter_complex = ";\n".join(v_filters + a_filters)
    filter_script_path = os.path.join(out_dir, f"filter_base_{os.path.splitext(voice_name)[0]}.txt")
    with open(filter_script_path, "w", encoding="utf-8") as f:
        f.write(filter_complex)

    creation_flags = 0x08000000 if os.name == "nt" else 0
    temp_main_mp4 = os.path.join(out_dir, f"temp_main_{os.path.splitext(voice_name)[0]}.mp4")

    log_cb(f"[{voice_name}] Đang render video nền + chèn cảnh trám...")
    ffmpeg_cmd = ["ffmpeg", "-y"] + inputs + [
        *FFMPEG_FILTER_MEMORY_GUARD,
        "-filter_complex_script", filter_script_path,
        "-map", outv_map,
    ]
    if outa_map:
        ffmpeg_cmd += ["-map", outa_map]
    ffmpeg_cmd += [
        "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest",
        temp_main_mp4,
    ]

    with ffmpeg_heavy_render_lock:
        process = subprocess.run(ffmpeg_cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore", creationflags=creation_flags)
    if process.returncode != 0:
        raise Exception(f"Lỗi FFmpeg: {process.stderr[-1500:]}")

    safe_stem = os.path.splitext(voice_name)[0]
    temp_token = f"{safe_stem}_{int(time.time() * 1000)}_{threading.get_ident()}"
    temp_frame_jpg = os.path.join(out_dir, f"temp_frame_{temp_token}.jpg")
    temp_cover_png = os.path.join(out_dir, f"temp_cover_{temp_token}.png")

    if not config.get("enable_cover", True):
        shutil.copy2(temp_main_mp4, out_file)
        if not (os.path.exists(out_file) and os.path.getsize(out_file) > 0):
            raise Exception(f"Không lưu được video đầu ra cho {voice_name}")
        log_cb(f"[{voice_name}] ⏭️ Tài khoản này tắt làm ảnh bìa, xuất video không gắn bìa.")
        for f_path in [filter_script_path, temp_main_mp4, temp_frame_jpg, temp_cover_png]:
            if os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except Exception:
                    pass
        return list(dict.fromkeys(used_brolls))

    extract_points = []
    if voice_dur > 2.0:
        random_sec = round(random.uniform(1.0, max(1.1, voice_dur - 1.0)), 2)
        extract_points = [random_sec, round(voice_dur / 2, 2), 0.5]
    else:
        extract_points = [0.0]

    frame_ready = False
    frame_error = ""
    for point in extract_points:
        frame_result = subprocess.run(
            ["ffmpeg", "-y", "-ss", f"{point:.2f}", "-i", temp_main_mp4, "-frames:v", "1", "-q:v", "2", temp_frame_jpg],
            capture_output=True, text=True, encoding="utf-8", errors="ignore", creationflags=creation_flags,
        )
        if frame_result.returncode == 0 and os.path.exists(temp_frame_jpg) and os.path.getsize(temp_frame_jpg) > 0:
            frame_ready = True
            break
        frame_error = (frame_result.stderr or frame_result.stdout or "Không rõ lỗi")[-400:]

    if not frame_ready:
        try:
            img = Image.new("RGBA", (1080, 1920), (22, 28, 36, 255))
            draw = ImageDraw.Draw(img)
            clean_proj_name = " ".join(proj_name.replace("_", " ").split()).upper()
            display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_proj_name, 1080, 1920, custom_font)
            draw.multiline_text(
                (540, 960),
                display_text,
                font=font,
                fill="white",
                align="center",
                anchor="mm",
                spacing=line_spacing,
                stroke_width=stroke_w,
                stroke_fill="black",
            )
            img.convert("RGB").save(temp_cover_png)
            frame_ready = True
            log_cb(f"[{voice_name}] ⚠️ Không trích được frame làm bìa, dùng bìa nền dự phòng. {frame_error[:120]}")
        except Exception as e:
            frame_error = str(e)

    final_video_ready = False
    if frame_ready:
        try:
            if os.path.exists(temp_frame_jpg) and os.path.getsize(temp_frame_jpg) > 0:
                with Image.open(temp_frame_jpg).convert("RGBA") as img:
                    draw = ImageDraw.Draw(img)
                    img_w, img_h = img.size
                    clean_proj_name = " ".join(proj_name.replace("_", " ").split()).upper()
                    display_text, font, stroke_w, line_spacing = _choose_cover_layout(draw, clean_proj_name, img_w, img_h, custom_font)
                    draw.multiline_text(
                        (img_w / 2, img_h / 2),
                        display_text,
                        font=font,
                        fill="white",
                        align="center",
                        anchor="mm",
                        spacing=line_spacing,
                        stroke_width=stroke_w,
                        stroke_fill="black",
                    )
                    img.convert("RGB").save(temp_cover_png)

            ffmpeg_concat_cmd = [
                "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", temp_main_mp4,
                "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a",
                "-c:v", "h264_nvenc", "-preset", "p1", "-b:v", "8000k", "-c:a", "copy", out_file,
            ]
            concat_result = subprocess.run(ffmpeg_concat_cmd, capture_output=True, text=True, errors="ignore", creationflags=creation_flags)
            final_video_ready = concat_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0

            if not final_video_ready:
                ffmpeg_concat_fallback_cmd = [
                    "ffmpeg", "-y", "-loop", "1", "-t", "0.1", "-i", temp_cover_png, "-i", temp_main_mp4,
                    "-filter_complex", "[0:v][1:v]concat=n=2:v=1:a=0[v]", "-map", "[v]", "-map", "1:a",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", out_file,
                ]
                concat_fallback_result = subprocess.run(ffmpeg_concat_fallback_cmd, capture_output=True, text=True, errors="ignore", creationflags=creation_flags)
                final_video_ready = concat_fallback_result.returncode == 0 and os.path.exists(out_file) and os.path.getsize(out_file) > 0
                if final_video_ready:
                    log_cb(f"[{voice_name}] ⚠️ NVENC gắn bìa lỗi, đã fallback sang libx264 thành công.")
        except Exception:
            pass

    if not final_video_ready:
        log_cb(f"[{voice_name}] ⚠️ Không gắn được bìa, xuất video gốc không bìa. {frame_error[:120]}")
        shutil.copy2(temp_main_mp4, out_file)
        final_video_ready = os.path.exists(out_file) and os.path.getsize(out_file) > 0

    if not final_video_ready:
        raise Exception(f"Không lưu được video đầu ra cho {voice_name}")

    for f_path in [filter_script_path, temp_main_mp4, temp_frame_jpg, temp_cover_png]:
        if os.path.exists(f_path):
            try:
                os.remove(f_path)
            except Exception:
                pass

    return list(dict.fromkeys(used_brolls))
