const DEFAULT_WS_URL = "ws://127.0.0.1:8765";
const TARGET_URL = "https://shop.tiktok.com/streamer/showcase/product/list";
const UPLOAD_URL = "https://www.tiktok.com/tiktokstudio/upload";
const CONNECT_RETRY_MS = 3000;
const STEP_DELAY_MS = 600;
let ws = null;
let connecting = false;
let isFilling = false;
let receiverId = "";
const processedRequestIds = new Set();
const PENDING_URL_KEY = "tiktok_auto_link_pending_url";
const BADGE_ID = "tiktok-auto-link-badge";

setStatusBadge("loaded");
log("Content script loaded.");

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function setStatusBadge(text) {
  let badge = document.getElementById(BADGE_ID);
  if (!badge) {
    badge = document.createElement("div");
    badge.id = BADGE_ID;
    badge.style.position = "fixed";
    badge.style.right = "12px";
    badge.style.bottom = "12px";
    badge.style.zIndex = "999999";
    badge.style.background = "#0f172a";
    badge.style.color = "#ffffff";
    badge.style.padding = "6px 10px";
    badge.style.borderRadius = "10px";
    badge.style.fontSize = "12px";
    badge.style.fontFamily = "Arial, sans-serif";
    badge.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";
    badge.style.opacity = "0.9";
    badge.textContent = "Auto Link: ready";
    document.documentElement.appendChild(badge);
  }
  if (text) {
    badge.textContent = "Auto Link: " + text;
  }
}

function log(msg) {
  console.log("[TikTok Auto Link]", msg);
  setStatusBadge(msg);
}

function textEquals(el, text) {
  return (el && el.textContent || "").trim() === text;
}

function findButtonByText(text) {
  const buttons = Array.from(document.querySelectorAll("button"));
  return buttons.find((btn) => textEquals(btn, text)) ||
    buttons.find((btn) => (btn.textContent || "").trim().includes(text)) ||
    null;
}

function findUrlInput() {
  return document.querySelector("input[data-tid='m4b_input'][placeholder*='URL sản phẩm']") ||
    document.querySelector("input[data-tid='m4b_input'][placeholder*='URL']") ||
    document.querySelector("input[placeholder*='URL sản phẩm']") ||
    document.querySelector("input[placeholder^='Vui lòng nhập URL']");
}

function findAddProductButton() {
  return document.querySelector("button.pc_add_product") || findButtonByText("Thêm sản phẩm");
}

function findCloseDrawerButton() {
  return document.querySelector("span.arco-drawer-close-icon");
}

function findSuccessToast() {
  const messages = Array.from(document.querySelectorAll("span.arco-message-content, .arco-message-content"));
  return messages.find((el) => (el.textContent || "").includes("Đã thêm thành công")) || null;
}

function readReceiverIdFromPage() {
  const el = document.querySelector(
    "span.text-body-s-medium.text-white\\/60.px-8.py-3"
  );
  return el ? el.textContent.trim() : "";
}

function sendHello() {
  if (!receiverId) {
    return;
  }
  if (ws && ws.readyState === WebSocket.OPEN) {
    try {
      ws.send(JSON.stringify({ type: "hello", receiver: receiverId }));
    } catch {
      // ignore
    }
  }
}

function ensureReceiverId(callback) {
  chrome.storage.local.get(["receiverId"], (result) => {
    receiverId = (result.receiverId || "").trim();
    if (!receiverId) {
      receiverId = "chrome-" + Math.random().toString(36).slice(2, 8);
      chrome.storage.local.set({ receiverId }, () => callback(receiverId));
      return;
    }
    callback(receiverId);
  });
}

function updateReceiverId(newId) {
  if (!newId || newId === receiverId) {
    return;
  }
  receiverId = newId;
  chrome.storage.local.set({ receiverId: receiverId });
  log("Receiver ID set: " + receiverId);
  sendHello();
}

function startReceiverIdWatch() {
  if (receiverId) {
    return;
  }
  let tries = 0;
  const timer = setInterval(() => {
    tries += 1;
    const found = readReceiverIdFromPage();
    if (found) {
      updateReceiverId(found);
      clearInterval(timer);
      return;
    }
    if (tries >= 60) {
      clearInterval(timer);
    }
  }, 1000);
}

async function waitForElement(getter, timeoutMs = 20000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const el = getter();
    if (el) {
      return el;
    }
    await sleep(200);
  }
  return null;
}

async function clickIfExists(getter) {
  const el = getter();
  if (el) {
    el.click();
    return true;
  }
  return false;
}

function setInputValue(input, value) {
  input.focus();
  input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

function setEditableValue(el, value) {
  el.focus();
  if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
    el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return;
  }
  el.textContent = value;
  el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
}

function reportPostDone(requestId, ok, error = "") {
  try {
    chrome.runtime.sendMessage({ type: "post_done", requestId, ok, error });
  } catch {
    // ignore
  }
}

function getPendingUrlPayload() {
  const raw = sessionStorage.getItem(PENDING_URL_KEY) || "";
  if (!raw) return { url: "", requestId: "" };
  try {
    const obj = JSON.parse(raw);
    if (obj && typeof obj === "object") {
      return { url: (obj.url || ""), requestId: (obj.requestId || "") };
    }
  } catch {
    // Backward compat: raw URL string
  }
  return { url: raw, requestId: "" };
}

function setPendingUrlPayload(url, requestId) {
  sessionStorage.setItem(PENDING_URL_KEY, JSON.stringify({ url, requestId: requestId || "" }));
}

function clearPendingUrl() {
  sessionStorage.removeItem(PENDING_URL_KEY);
}

function maybeRunPending() {
  const pending = getPendingUrlPayload();
  if (!pending.url) {
    return;
  }
  if (!location.href.startsWith(TARGET_URL)) {
    return;
  }
  if (isFilling) {
    return;
  }
  log("Running pending URL.");
  runFillSequence(pending.url, pending.requestId);
}

function watchForUrlInput() {
  if (!location.href.startsWith(TARGET_URL)) {
    return;
  }
  const observer = new MutationObserver(() => {
    const pending = getPendingUrlPayload();
    if (findUrlInput() && pending.url && !isFilling) {
      log("URL input appeared. Running pending URL.");
      runFillSequence(pending.url, pending.requestId);
      observer.disconnect();
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  setTimeout(() => observer.disconnect(), 30000);
}

async function runFillSequence(productUrl, requestId = "") {
  if (isFilling) {
    log("Fill already in progress. Skipping.");
    return;
  }

  isFilling = true;
  try {
    log("Starting fill sequence.");

    await clickIfExists(() => findButtonByText("Thêm sản phẩm mới"));
    await sleep(STEP_DELAY_MS);

    log("Waiting for URL input (up to 20s)...");
    const input = await waitForElement(findUrlInput, 20000);
    if (!input) {
      log("URL input not found.");
      chrome.runtime.sendMessage({ type: "link_done", requestId, receiver: receiverId, url: productUrl, ok: false });
      return;
    }

    setInputValue(input, productUrl);
    await sleep(STEP_DELAY_MS);

    await clickIfExists(() => findButtonByText("URL sản phẩm"));
    await sleep(1200);

    const addBtn = await waitForElement(findAddProductButton, 20000);
    if (addBtn) {
      addBtn.click();
      log("Clicked add product.");
    } else {
      log("Add product button not found.");
    }

    // Wait for success toast before closing drawer.
    log("Waiting for success message...");
    const toast = await waitForElement(findSuccessToast, 20000);
    const ok = Boolean(toast);
    if (ok) {
      log("Success: added 1 product.");
    } else {
      log("No success message found (timeout).");
    }

    await sleep(800);
    const closeBtn = findCloseDrawerButton();
    if (closeBtn) {
      closeBtn.click();
      log("Closed drawer.");
    } else {
      log("Close drawer button not found.");
    }
    clearPendingUrl();
    if (requestId && ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({ type: "link_done", requestId, receiver: receiverId, url: productUrl, ok }));
      } catch {
        // ignore
      }
    }
    if (requestId) {
      try {
        chrome.runtime.sendMessage({ type: "link_done", requestId, receiver: receiverId, url: productUrl, ok });
      } catch {
        // ignore
      }
    }

    // Stay on the page and wait for the next command.
  } finally {
    isFilling = false;
  }
}

async function runUploadPostSequence(captionText, requestId = "") {
  try {
    log("Starting upload/post sequence.");

    await sleep(2500);
    const captionBox = await waitForElement(() => (
      document.querySelector("textarea") ||
      document.querySelector("div[contenteditable='true']") ||
      document.querySelector("[role='textbox']")
    ), 60000);
    if (!captionBox) throw new Error("Không thấy ô caption");
    setEditableValue(captionBox, captionText || "");

    await sleep(1000);
    await clickIfExists(() => findButtonByText("Thêm liên kết") || findButtonByText("Add link"));
    await sleep(1200);
    await clickIfExists(() => findButtonByText("Sản phẩm") || findButtonByText("Product"));
    await sleep(1200);

    const addBtn = await waitForElement(() => findButtonByText("Thêm") || findButtonByText("Add"), 20000);
    if (!addBtn) throw new Error("Không thấy nút thêm sản phẩm đầu tiên");
    addBtn.click();

    const postBtn = await waitForElement(() => {
      const direct = document.querySelector('button[data-e2e="post_video_button"]');
      if (direct && !direct.disabled && direct.getAttribute("aria-disabled") !== "true" && direct.getAttribute("data-disabled") !== "true") return direct;
      const btn = findButtonByText("Đăng") || findButtonByText("Post") || findButtonByText("Publish");
      if (btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") return btn;
      return null;
    }, 12 * 60 * 1000);
    if (!postBtn) throw new Error("Không thấy nút Đăng khả dụng");

    try { window.scrollTo(0, document.body.scrollHeight); } catch {}
    await sleep(500);
    postBtn.click();
    await sleep(5000);
    reportPostDone(requestId, true);
  } catch (error) {
    reportPostDone(requestId, false, error && error.message ? error.message : String(error));
  }
}

function parseMessage(message) {
  try {
    const data = JSON.parse(message);
    if (data && typeof data === "object") {
      return {
        url: data.url || data.product_url || "",
        target: data.target || data.receiver_id || "",
        requestId: data.requestId || data.request_id || "",
      };
    }
  } catch {
    // Not JSON
  }

  if (typeof message === "string" && message.startsWith("http")) {
    return { url: message.trim(), target: "" };
  }
  return { url: "", target: "", requestId: "" };
}

function connect(wsUrl) {
  if (connecting || (ws && ws.readyState === WebSocket.OPEN)) {
    return;
  }

  connecting = true;
  log("Connecting to " + wsUrl + " ...");
  try {
    ws = new WebSocket(wsUrl);
  } catch (err) {
    log("WebSocket init failed: " + err.message);
    connecting = false;
    return;
  }

  ws.addEventListener("open", () => {
    connecting = false;
    log("Connected: " + wsUrl);
    startReceiverIdWatch();
    sendHello();
  });

  ws.addEventListener("message", (event) => {
    const payload = parseMessage(event.data);
    if (!payload.url) {
      log("Message ignored.");
      return;
    }
    // If a target is specified, we must have a receiverId and it must match.
    if (payload.target && !receiverId) {
      log("Message ignored: receiver not set.");
      return;
    }
    if (receiverId && payload.target && payload.target !== receiverId) {
      log("Message ignored: receiver mismatch.");
      return;
    }

    if (payload.requestId) {
      if (processedRequestIds.has(payload.requestId)) {
        log("Message ignored: request already processed.");
        return;
      }
      processedRequestIds.add(payload.requestId);
    }
    if (!location.href.startsWith(TARGET_URL)) {
      log("Navigating to target page...");
      setPendingUrlPayload(payload.url, payload.requestId);
      location.href = TARGET_URL;
      return;
    }
    runFillSequence(payload.url, payload.requestId);
  });

  ws.addEventListener("close", () => {
    connecting = false;
    log("Disconnected. Retrying...");
    setTimeout(() => connect(wsUrl), CONNECT_RETRY_MS);
  });

  ws.addEventListener("error", () => {
    log("WebSocket error. Retrying...");
    try {
      ws.close();
    } catch {
      // ignore
    }
  });
}

ensureReceiverId(() => sendHello());

const pending = getPendingUrlPayload();
if (pending.url && location.href.startsWith(TARGET_URL)) {
  log("Found pending URL after navigation.");
  runFillSequence(pending.url, pending.requestId);
}

setInterval(maybeRunPending, 1000);
watchForUrlInput();

chrome.storage.onChanged.addListener((changes) => {
  if (changes.receiverId) {
    receiverId = (changes.receiverId.newValue || "").trim();
    sendHello();
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message) {
    return;
  }
  if (message.type === "fill_product" && message.url) {
    runFillSequence(message.url, message.requestId || "");
  }
  if (message.type === "upload_post") {
    runUploadPostSequence(message.caption || "", message.requestId || "");
  }
});
