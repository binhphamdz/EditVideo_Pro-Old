import os
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import concurrent.futures
from datetime import datetime

from .ai_services import get_transcription, get_director_timeline
from .video_engine import render_faceless_video
from paths import BASE_PATH, resource_path



class FacelessTab:
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.completed_count = 0
        self.completed_lock = threading.Lock()
        self.opening_lock = threading.Lock()
        self.used_opening_videos = set()
        self.broll_lock = threading.Lock()
        self.used_broll_videos = set()
        self.setup_ui()

    def setup_ui(self):
        top_container = tk.Frame(self.parent, bg="#f4f6f9")
        top_container.pack(fill="x", padx=10, pady=5)

        # CỘT TRÁI
        top_frame = tk.LabelFrame(top_container, text=" 1. Cấu Hình & API ", font=("Arial", 11, "bold"), bg="#ffffff", padx=15, pady=10)
        top_frame.pack(side="left", fill="both", expand=True, padx=(0, 5))

        fr_row1 = tk.Frame(top_frame, bg="#ffffff")
        fr_row1.pack(fill="x", pady=5)
        tk.Label(fr_row1, text="Chọn Project:", bg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")
        self.combo_proj = ttk.Combobox(fr_row1, state="readonly", width=35, font=("Arial", 10))
        self.combo_proj.pack(side="left", padx=5)
        self.combo_proj.bind("<<ComboboxSelected>>", self.on_project_select)

        # [MỚI] CONTAINER CHỨA VOICE, TRANSITIONS, TỐC ĐỘ NẰM NGANG
        fr_voice_trans_container = tk.Frame(top_frame, bg="#ffffff")
        fr_voice_trans_container.pack(fill="both", expand=True, pady=5)

        # ===== TRÁI: CHỌN VOICE =====
        fr_voice = tk.LabelFrame(fr_voice_trans_container, text="Chọn Voice (Ctrl):", bg="#ffffff", font=("Arial", 9, "bold"), padx=5, pady=5)
        fr_voice.pack(side="left", fill="both", expand=True, padx=(0, 5))
        
        self.lst_voices = tk.Listbox(fr_voice, selectmode=tk.MULTIPLE, height=6, width=22, font=("Arial", 10), exportselection=False)
        scroll_voice = ttk.Scrollbar(fr_voice, orient="vertical", command=self.lst_voices.yview)
        self.lst_voices.configure(yscrollcommand=scroll_voice.set)
        self.lst_voices.pack(side="left", fill="both", expand=True)
        scroll_voice.pack(side="left", fill="y")

        # ===== GIỮA: CHỌN HIỆU ỨNG CHUYỂN CẢNH =====
        fr_trans_container = tk.LabelFrame(fr_voice_trans_container, text="Chọn Hiệu Ứng (Ctrl):", bg="#ffffff", font=("Arial", 9, "bold"), padx=5, pady=5)
        fr_trans_container.pack(side="left", fill="both", expand=True, padx=(0, 5))
        
        # Danh sách hiệu ứng với mô tả
        self.transitions = {
            "fade": "⬜ Mờ dần (Fade)",
            "slide_left": "⬅️ Trượt Trái",
            "slide_right": "➡️ Trượt Phải",
            "slide_up": "⬆️ Trượt Lên",
            "slide_down": "⬇️ Trượt Xuống",
            "wipe_left": "⬅️ Quét Trái",
            "wipe_right": "➡️ Quét Phải",
            "hlslice": "🔀 Vụt Ngang (TikTok)",
            "zoom_in": "🔍 Phóng To",
        }
        
        self.lst_trans = tk.Listbox(fr_trans_container, selectmode=tk.MULTIPLE, height=6, width=20, font=("Arial", 9), exportselection=False)
        for trans_key, trans_display in self.transitions.items():
            self.lst_trans.insert(tk.END, trans_display)
        
        # Load saved transitions
        saved_trans = [
            trans_key
            for trans_key in self.main_app.config.get("selected_transitions", ["fade"])
            if trans_key in self.transitions
        ]
        if not saved_trans:
            saved_trans = ["fade"]
        for idx, (trans_key, trans_display) in enumerate(self.transitions.items()):
            if trans_key in saved_trans:
                self.lst_trans.selection_set(idx)
        
        scroll_trans = ttk.Scrollbar(fr_trans_container, orient="vertical", command=self.lst_trans.yview)
        self.lst_trans.configure(yscrollcommand=scroll_trans.set)
        self.lst_trans.pack(side="left", fill="both", expand=True)
        scroll_trans.pack(side="left", fill="y")
        
        # Gắn auto-save cho transitions
        self.lst_trans.bind("<<ListboxSelect>>", self._save_selected_transitions)
        
        # ===== PHẢI: SLIDER TỐC ĐỘ CHUYỂN CẢNH =====
        fr_trans_speed = tk.LabelFrame(fr_voice_trans_container, text="Tốc Độ (s):", bg="#ffffff", font=("Arial", 9, "bold"), padx=5, pady=5)
        fr_trans_speed.pack(side="left", fill="both", padx=(0, 0))
        
        self.scale_trans_dur = tk.Scale(fr_trans_speed, from_=0.3, to=2.0, resolution=0.1, orient="vertical", bg="#ffffff", length=180)
        self.scale_trans_dur.set(self.main_app.config.get("trans_duration", 0.5))
        self.scale_trans_dur.pack(fill="both", expand=True)
        self.scale_trans_dur.bind("<ButtonRelease-1>", self._save_config_auto)
        
        # Label hiển thị giá trị hiện tại
        self.lbl_trans_dur = tk.Label(fr_trans_speed, text=f"{self.scale_trans_dur.get():.1f}s", bg="#ffffff", font=("Arial", 10, "bold"), fg="#c0392b")
        self.lbl_trans_dur.pack(pady=(5, 0))
        
        # Update label khi slider thay đổi
        def update_trans_dur_label(val):
            self.lbl_trans_dur.config(text=f"{float(val):.1f}s")
        
        self.scale_trans_dur.config(command=update_trans_dur_label)

        fr_row2 = tk.Frame(top_frame, bg="#ffffff")
        fr_row2.pack(fill="x", pady=5)
        tk.Label(fr_row2, text="Groq Key (Bóc băng):", bg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")
        self.ent_groq = tk.Entry(fr_row2, width=35, show="*")
        self.ent_groq.insert(0, self.main_app.config.get("groq_key", ""))
        self.ent_groq.pack(side="left", padx=5)
        tk.Label(fr_row2, text="⚙️ Cấu hình AI tại Tab 10", bg="#ffffff", font=("Arial", 9, "italic"), fg="#7f8c8d").pack(side="left", padx=10)

        fr_row3 = tk.Frame(top_frame, bg="#ffffff")
        fr_row3.pack(fill="x", pady=5)
        tk.Label(fr_row3, text="Font Bìa:", bg="#ffffff", font=("Arial", 9, "bold")).pack(side="left")
        self.ent_font = tk.Entry(fr_row3, width=25)
        self.ent_font.insert(0, self.main_app.config.get("font_path", ""))
        self.ent_font.pack(side="left", padx=5)
        tk.Button(fr_row3, text="📂 Chọn Font", bg="#3498db", fg="white", font=("Arial", 8, "bold"), command=self.pick_font).pack(side="left")

        self.use_cover = tk.BooleanVar(value=self._get_profile_cover_enabled())
        self.chk_use_cover = tk.Checkbutton(fr_row3, text="Làm ảnh bìa cho tài khoản này", variable=self.use_cover, bg="#ffffff")
        self.chk_use_cover.pack(side="left", padx=10)

        fr_row_srt = tk.Frame(top_frame, bg="#ffffff")
        fr_row_srt.pack(fill="x", pady=5)
        tk.Label(fr_row_srt, text="Bóc Băng Bằng:", bg="#ffffff", font=("Arial", 9, "bold"), fg="#8e44ad").pack(side="left")
        self.boc_bang_mode = tk.StringVar(value=self.main_app.config.get("boc_bang_mode", "groq"))
        tk.Radiobutton(fr_row_srt, text="Groq (Nhanh)", variable=self.boc_bang_mode, value="groq", bg="#ffffff").pack(side="left", padx=5)
        tk.Radiobutton(fr_row_srt, text="OhFree (Chuẩn)", variable=self.boc_bang_mode, value="ohfree", bg="#ffffff").pack(side="left", padx=5)

        fr_row_thread = tk.Frame(top_frame, bg="#ffffff")
        fr_row_thread.pack(fill="x", pady=5)
        tk.Label(fr_row_thread, text="Số Luồng:", bg="#ffffff", font=("Arial", 9, "bold"), fg="#c0392b").pack(side="left")
        self.spin_threads = ttk.Spinbox(fr_row_thread, from_=1, to=5, width=5, font=("Arial", 10, "bold"), command=self._save_config_auto)
        self.spin_threads.set(self.main_app.config.get("threads", 2))
        self.spin_threads.pack(side="left", padx=5)

        fr_row_v0 = tk.Frame(top_frame, bg="#ffffff")
        fr_row_v0.pack(fill="x", pady=5)
        self.use_v0 = tk.BooleanVar(value=self.main_app.config.get("enable_v0", True))
        self.chk_use_v0 = tk.Checkbutton(fr_row_v0, text="Bật Vòng 0 (gom SRT)", variable=self.use_v0, bg="#ffffff")
        self.chk_use_v0.pack(side="left")

        # CỘT PHẢI
        adj_frame = tk.LabelFrame(top_container, text=" ⚙️ Tùy Chỉnh ", font=("Arial", 11, "bold"), bg="#ffffff", padx=15, pady=10)
        adj_frame.pack(side="right", fill="y", padx=(5, 0))
        tk.Label(adj_frame, text="Âm lượng Broll (%):", bg="#ffffff", font=("Arial", 9, "bold"), fg="#27ae60").pack(anchor="w", pady=(2, 2))
        self.scale_broll_vol = tk.Scale(adj_frame, from_=0, to=100, resolution=5, orient="horizontal", bg="#ffffff", length=200)
        self.scale_broll_vol.set(self.main_app.config.get("broll_vol", 30))
        self.scale_broll_vol.pack(anchor="w")

        tk.Label(adj_frame, text="Tăng tốc video tổng (x):", bg="#ffffff", font=("Arial", 9, "bold")).pack(anchor="w", pady=(0, 2))
        self.scale_speed = tk.Scale(adj_frame, from_=0.5, to=3.0, resolution=0.1, orient="horizontal", bg="#ffffff", length=200)
        self.scale_speed.set(self.main_app.config.get("video_speed", 1.0))
        self.scale_speed.pack(anchor="w")
        
        tk.Label(adj_frame, text="Tăng tốc cảnh trám tối đa (x):", bg="#ffffff", font=("Arial", 9, "bold")).pack(anchor="w", pady=(2, 2))
        self.scale_auto_speed = tk.Scale(adj_frame, from_=1.0, to=3.0, resolution=0.1, orient="horizontal", bg="#ffffff", length=200)
        self.scale_auto_speed.set(self.main_app.config.get("auto_speed_max", 1.4))
        self.scale_auto_speed.pack(anchor="w")

        tk.Label(adj_frame, text="Sáng (1.0 = Gốc):", bg="#ffffff", font=("Arial", 9, "bold")).pack(anchor="w", pady=(2, 2))
        self.scale_bright = tk.Scale(adj_frame, from_=0.5, to=2.0, resolution=0.1, orient="horizontal", bg="#ffffff", length=200)
        self.scale_bright.set(self.main_app.config.get("video_bright", 1.0))
        self.scale_bright.pack(anchor="w")

        self.use_trans = tk.BooleanVar(value=self.main_app.config.get("use_trans", True))
        self.chk_use_trans = tk.Checkbutton(adj_frame, text="Bật hiệu ứng chuyển cảnh", variable=self.use_trans, bg="#ffffff")
        self.chk_use_trans.pack(anchor="w", pady=(5, 0))

        self.use_sfx = tk.BooleanVar(value=self.main_app.config.get("use_sfx", True))
        self.chk_use_sfx = tk.Checkbutton(adj_frame, text="Bật âm chuyển cảnh", variable=self.use_sfx, bg="#ffffff")
        self.chk_use_sfx.pack(anchor="w")

        # [MỚI] Gắn auto-save vào các slider và checkbox
        self.scale_broll_vol.bind("<ButtonRelease-1>", self._save_config_auto)
        self.scale_speed.bind("<ButtonRelease-1>", self._save_config_auto)
        self.scale_auto_speed.bind("<ButtonRelease-1>", self._save_config_auto)
        self.scale_bright.bind("<ButtonRelease-1>", self._save_config_auto)
        self.use_trans.trace_add("write", self._on_transition_toggle)
        self.use_sfx.trace_add("write", self._save_config_auto)
        self.ent_groq.bind("<KeyRelease>", self._save_config_auto)
        self.ent_font.bind("<KeyRelease>", self._save_config_auto)
        self.use_cover.trace_add("write", self._save_config_auto)
        self.spin_threads.bind("<KeyRelease>", self._save_config_auto)
        self.spin_threads.bind("<FocusOut>", self._save_config_auto)
        self.boc_bang_mode.trace_add("write", self._save_config_auto)
        self.use_v0.trace_add("write", self._save_config_auto)
        self._sync_transition_controls()

        # LOG VÀ NÚT RENDER
        mid_frame = tk.LabelFrame(self.parent, text=" 2. Log Tiến Trình ", font=("Arial", 11, "bold"), bg="#ffffff", padx=15, pady=5)
        mid_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.txt_log = tk.Text(mid_frame, bg="#1e272e", fg="#2ecc71", font=("Consolas", 10), state="disabled")
        self.txt_log.pack(fill="both", expand=True, pady=5)

        bot_frame = tk.Frame(self.parent, bg="#f4f6f9")
        bot_frame.pack(fill="x", padx=10, pady=5)
        self.btn_run_batch = tk.Button(bot_frame, text="🚀 BẤM RENDER (ĐA LUỒNG)", bg="#c0392b", fg="white", font=("Arial", 14, "bold"), pady=10, command=self.start_batch_process)
        self.btn_run_batch.pack(fill="x")

    def _get_profile_cover_enabled(self):
        profile_name = self.main_app.get_active_profile_name()
        profile_settings = self.main_app.config.get("profile_enable_cover", {})
        if isinstance(profile_settings, dict) and profile_name in profile_settings:
            return bool(profile_settings[profile_name])
        return bool(self.main_app.config.get("enable_cover", True))

    def _sync_profile_settings(self):
        if hasattr(self, "use_cover"):
            self.use_cover.set(self._get_profile_cover_enabled())

    def _save_config_auto(self, *args):
        """[MỚI] Tự động lưu config khi bất kỳ setting nào thay đổi"""
        try:
            self.main_app.config["broll_vol"] = self.scale_broll_vol.get()
            self.main_app.config["video_speed"] = self.scale_speed.get()
            self.main_app.config["auto_speed_max"] = self.scale_auto_speed.get()
            self.main_app.config["video_bright"] = self.scale_bright.get()
            self.main_app.config["use_trans"] = self.use_trans.get()
            self.main_app.config["use_sfx"] = self.use_sfx.get()
            self.main_app.config["groq_key"] = self.ent_groq.get().strip()
            self.main_app.config["font_path"] = self.ent_font.get().strip()
            self.main_app.config["boc_bang_mode"] = self.boc_bang_mode.get()
            self.main_app.config["enable_v0"] = self.use_v0.get()
            profile_name = self.main_app.get_active_profile_name()
            profile_settings = self.main_app.config.get("profile_enable_cover", {})
            if not isinstance(profile_settings, dict):
                profile_settings = {}
            profile_settings[profile_name] = self.use_cover.get()
            self.main_app.config["profile_enable_cover"] = profile_settings
            self.main_app.config["enable_cover"] = self.use_cover.get()
            self.main_app.config["trans_duration"] = self.scale_trans_dur.get()  # [MỚI] Lưu tốc độ chuyển cảnh
            try:
                self.main_app.config["threads"] = int(self.spin_threads.get())
            except ValueError:
                pass
            self.main_app.save_config()
        except Exception as e:
            print(f"⚠️ Lỗi auto-save config: {e}")

    def _ensure_transition_selection(self):
        if self.lst_trans.curselection():
            return

        saved_keys = [
            trans_key
            for trans_key in self.main_app.config.get("selected_transitions", ["fade"])
            if trans_key in self.transitions
        ]
        if not saved_keys:
            saved_keys = ["fade"]

        transition_indices = {trans_key: idx for idx, trans_key in enumerate(self.transitions.keys())}
        for trans_key in saved_keys:
            index = transition_indices.get(trans_key)
            if index is not None:
                self.lst_trans.selection_set(index)

    def _sync_transition_controls(self):
        is_enabled = self.use_trans.get()
        self.lst_trans.configure(state=tk.NORMAL if is_enabled else tk.DISABLED)
        self.scale_trans_dur.configure(state=tk.NORMAL if is_enabled else tk.DISABLED)
        self.chk_use_sfx.configure(state=tk.NORMAL if is_enabled else tk.DISABLED)

        if is_enabled:
            self._ensure_transition_selection()

    def _on_transition_toggle(self, *args):
        self._sync_transition_controls()
        self._save_config_auto()

    def update_combo_projects(self):
        self._sync_profile_settings()
        proj_list = []
        self.pid_map = {}
        for pid, pdata in self.main_app.projects.items():
            if pdata.get('status', 'active') == 'active':
                name = pdata.get('name', 'Unknown')
                proj_list.append(name)
                self.pid_map[name] = pid
                
        self.combo_proj.config(values=proj_list)
        if proj_list: 
            self.combo_proj.current(0)
            self.on_project_select(None)

    def on_project_select(self, event):
        self.lst_voices.delete(0, tk.END)
        proj_name = self.combo_proj.get()
        if not proj_name: return
        voice_dir = os.path.join(self.main_app.get_proj_dir(self.pid_map[proj_name]), "Voices")
        if os.path.exists(voice_dir):
            for f in os.listdir(voice_dir):
                if f.lower().endswith(('.mp3', '.wav', '.m4a', '.mp4', '.mov', '.mkv', '.avi', '.webm', '.m4v')):
                    self.lst_voices.insert(tk.END, f)

    def _save_selected_transitions(self, event=None):
        """[MỚI] Lưu transitions đã chọn vào config"""
        if not self.use_trans.get():
            self._save_config_auto()
            return

        self._ensure_transition_selection()
        selected_indices = self.lst_trans.curselection()
        selected_trans_keys = [list(self.transitions.keys())[i] for i in selected_indices]
        self.main_app.config["selected_transitions"] = selected_trans_keys if selected_trans_keys else ["fade"]
        self._save_config_auto()  # Gồi hàm auto-save

    def pick_font(self):
        f_path = filedialog.askopenfilename(title="Chọn Font", filetypes=[("Font Files", "*.ttf *.otf")])
        if f_path:
            self.ent_font.delete(0, tk.END)
            self.ent_font.insert(0, f_path)
            self.main_app.config["font_path"] = f_path
            self.main_app.save_config()

    def add_log(self, msg, provider=None):
        self.main_app.root.after(0, self._insert_log, msg)
        self.main_app.log_event("tab2", msg, provider or "system")

    def _insert_log(self, msg):
        self.txt_log.config(state="normal")
        self.txt_log.insert(tk.END, f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")
        self.txt_log.see(tk.END)
        self.txt_log.config(state="disabled")

    def auto_render_from_bot(self, bot, chat_id):
        import os
        import threading
        from paths import BASE_PATH
        import database

        proj_name = self.combo_proj.get()
        if not proj_name: 
            return bot.send_message(chat_id, "❌ Sếp chưa chọn Project trên Tool! Hãy ra màn hình PC chọn Project trước nhé.")
            
        pid = self.pid_map.get(proj_name)
        if not pid:
            return bot.send_message(chat_id, "❌ Lỗi không tìm thấy ID của Project!")

        proj_dir = self.main_app.get_proj_dir(pid)
        voice_dir = os.path.join(proj_dir, "Voices")
        
        if not os.path.exists(voice_dir):
            return bot.send_message(chat_id, "❌ Thư mục Voices chưa được tạo!")

        db_proj_id = database.get_or_create_project(proj_name)
        
        with database.db_lock: 
            conn = database.get_connection()
            cursor = conn.cursor()
            
            # --- LUẬT THÉP 1: TÌM VOICE SẠCH 3 NGÀY ---
            # Lấy những voice CHƯA TỪNG DÙNG hoặc dùng quá 3 ngày trước.
            query_3_days = '''
                SELECT file_name FROM voices 
                WHERE project_id = ? 
                AND (last_used IS NULL OR last_used <= datetime('now', '-3 days', 'localtime'))
                ORDER BY usage_count ASC, last_used ASC
            '''
            cursor.execute(query_3_days, (db_proj_id,))
            rows = cursor.fetchall()
            all_voices = [r['file_name'] for r in rows]

            # --- LUẬT THÉP 2: NẾU THIẾU, BÙ THÊM BẰNG VOICE SẠCH 1 NGÀY ---
            # Giả sử Bot cần 3 voice, mà kho 3 ngày chỉ còn 1 voice. Ta sẽ bù thêm 2 voice từ kho 1 ngày.
            if len(all_voices) < 3:
                query_1_day = '''
                    SELECT file_name FROM voices 
                    WHERE project_id = ? 
                    AND last_used > datetime('now', '-3 days', 'localtime') 
                    AND last_used <= datetime('now', '-1 days', 'localtime')
                    ORDER BY last_used ASC
                '''
                cursor.execute(query_1_day, (db_proj_id,))
                rows_1_day = cursor.fetchall()
                
                for r in rows_1_day:
                    if r['file_name'] not in all_voices:
                        all_voices.append(r['file_name'])
                    if len(all_voices) >= 3:
                        break
            
            # Chốt sổ 3 voice đầu tiên tìm được
            final_voices = all_voices[:3]

            # Nếu vẫn trống trơn, nghĩa là tất cả voice đều đã dùng trong 24h qua!
            if not final_voices:
                conn.close()
                return bot.send_message(chat_id, "❌ KHO VOICE ĐÃ BỊ VẮT KIỆT!\nToàn bộ Voice đều đã được dùng trong 24h qua. Đang bảo vệ chống trùng lặp, sếp vui lòng nạp thêm file mp3 mới!")

            # 5. KHÓA GIỮ CHỖ (Ghi dấu ấn thời gian ngay lập tức)
            for v in final_voices:
                cursor.execute('''
                    UPDATE voices 
                    SET last_used = datetime('now', 'localtime') 
                    WHERE project_id = ? AND file_name = ?
                ''', (db_proj_id, v))
            conn.commit()
            conn.close()

        self.main_app.config["app_base_path"] = BASE_PATH 
        bot.send_message(chat_id, f"🎬 ĐẠO DIỄN AI NHẬN LỆNH!\n📁 Project: {proj_name}\n🎙️ Đã chốt {len(final_voices)} voice sạch (Né hoàn toàn hôm nay). Đang đưa vào lò...")
        with self.opening_lock:
            self.used_opening_videos.clear()
        with self.broll_lock:
            self.used_broll_videos.clear()
        
        threading.Thread(
            target=self._run_multithread_batch, 
            args=(final_voices, proj_dir, proj_name, bot, chat_id), 
            daemon=True
        ).start()

    def start_batch_process(self):
        import database
        import threading
        proj_name = self.combo_proj.get()
        selected_indices = self.lst_voices.curselection()
        
        if not proj_name or not selected_indices: 
            return messagebox.showwarning("Lỗi", "Vui lòng chọn Project và bôi đen Voice!")
        
        if self.use_trans.get():
            self._ensure_transition_selection()
            selected_trans = self.lst_trans.curselection()
            if not selected_trans:
                return messagebox.showwarning("Lỗi", "Vui lòng chọn ít nhất 1 Hiệu Ứng Chuyển Cảnh!")
        
        self._save_config_auto()
        if self.use_trans.get():
            self._save_selected_transitions()
        from paths import BASE_PATH
        self.main_app.config["app_base_path"] = BASE_PATH
        self.main_app.save_config()

        voices = [self.lst_voices.get(i) for i in selected_indices]
        
        # --- [BẢN ĐỘ MỚI] Bốc voice theo luồng ---
        import random
        random.shuffle(voices)
        
        with database.db_lock:  # BỌC KHÓA LUỒNG TẠI ĐÂY
            conn = database.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM projects WHERE name = ?", (proj_name,))
            db_proj_id = cursor.fetchone()['id']
            
            cursor.execute("SELECT file_name, usage_count FROM voices WHERE project_id = ?", (db_proj_id,))
            voice_usage = {r['file_name']: r['usage_count'] for r in cursor.fetchall()}
            conn.close()

        def get_usage_for_gui(v_name):
            for k, v in voice_usage.items():
                if k.lower() == v_name.lower(): return int(v)
            return 0
            
        voices.sort(key=get_usage_for_gui)
        
        pid = self.pid_map[proj_name]
        proj_dir = self.main_app.get_proj_dir(pid)

        with self.opening_lock:
            self.used_opening_videos.clear()
        with self.broll_lock:
            self.used_broll_videos.clear()
        
        self.btn_run_batch.config(state="disabled", text="⏳ ĐANG RENDER...")
        threading.Thread(target=self._run_multithread_batch, args=(voices, proj_dir, proj_name, None, None), daemon=True).start()

    def _run_multithread_batch(self, voices, proj_dir, proj_name, bot=None, chat_id=None):
        self.completed_count = 0
        batch_config = dict(self.main_app.config)
        batch_config["enable_cover"] = self._get_profile_cover_enabled()
        try:
            num_threads = max(1, int(batch_config.get("threads", 2)))
        except (TypeError, ValueError):
            num_threads = 2
        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            # Truyền thêm tham số thời gian delay để chống kẹt
            futures = [executor.submit(self._process_single, v, proj_dir, proj_name, batch_config) for v in voices]
            for future in concurrent.futures.as_completed(futures):
                try: future.result()
                except Exception as exc: self.add_log(f"❌ LUỒNG CRASH: {exc}")
        
        try:
            self.add_log("🧹 Đang dọn dẹp bộ nhớ FFmpeg ngầm...")
            os.system("taskkill /f /im ffmpeg-win-x86_64-v7.1.exe /T >nul 2>&1")
            os.system("taskkill /f /im ffmpeg.exe /T >nul 2>&1")
        except: pass
        
        self.add_log("=========================================")
        self.add_log(f"🎉 HOÀN TẤT! Thành công: {self.completed_count}/{len(voices)}.")
        self.main_app.root.after(0, lambda: self.btn_run_batch.config(state="normal", text="🚀 BẤM RENDER (ĐA LUỒNG)"))
        if bot and chat_id: bot.send_message(chat_id, f"🎉 Đã xuất xưởng {self.completed_count}/{len(voices)} video. Nhắn /icloud để nhận hàng!")
        
        try: self.main_app.tab4.load_excel_data()
        except: pass

    def _process_single(self, voice_name, proj_dir, proj_name, config=None):
        from main import GLOBAL_OUT_DIR
        import database
        from .video_engine import render_faceless_video, render_faceless_video_with_base, apply_video_speed_after_render
        from .ai_services import get_transcription, get_director_timeline
        from datetime import datetime
        import os
        config = config or self.main_app.config
        
        try:
            voice_path = os.path.join(proj_dir, "Voices", voice_name)
            voice_ext = os.path.splitext(voice_path)[1].lower()
            is_video_voice = voice_ext in (".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v")
            # Tạo tên file đầu ra: [Tên Project] Tên Voice_GiờPhútGiây.mp4
            out_file = os.path.join(GLOBAL_OUT_DIR, f"[{proj_name}] {os.path.splitext(voice_name)[0]}_{datetime.now().strftime('%H%M%S')}.mp4")
            pid = self.pid_map.get(proj_name)
            
            # =======================================================
            # 1. KẾT NỐI DATABASE & LẤY ID + BỐI CẢNH DỰ ÁN
            # =======================================================
            import database
            db_proj_id = database.get_or_create_project(proj_name)

            # Lấy thêm product_context để truyền cho AI Đạo diễn
            with database.db_lock:
                conn = database.get_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT product_context FROM projects WHERE id = ?", (db_proj_id,))
                p_row = cursor.fetchone()
                proj_context = p_row['product_context'] if (p_row and p_row['product_context']) else "Không có mô tả cụ thể."
                conn.close()
            # =======================================================
            # 2. BÓC BĂNG (Lấy nội dung chữ từ file âm thanh)
            # =======================================================
            try:
                # Ưu tiên lấy từ cache SRT đã bóc ở Tab 1
                voice_text = self.main_app.tab1.get_voice_srt_or_extract(pid, voice_name, voice_path)
                self.add_log(f"[{voice_name}] ✅ Dùng SRT (cache hoặc extract mới)")
            except Exception as e:
                self.add_log(f"[{voice_name}] ⚠️ Fallback extract: {str(e)[:50]}")
                voice_text = get_transcription(voice_path, voice_name, config.get("boc_bang_mode", "groq"), config, self.add_log)
            
            # =======================================================
            # 3. LẤY KHO CẢNH TRÁM (BROLL) TỪ DATABASE
            # =======================================================
            with database.db_lock:
                conn = database.get_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT file_name, duration, description, usage_count, keep_audio FROM brolls WHERE project_id = ? AND status = 'active'", (db_proj_id,))
                broll_rows = cursor.fetchall()
                conn.close()
            
            broll_data = {}
            broll_text = ""
            broll_usage = {}
            for r in broll_rows:
                v = r['file_name']
                # Tính độ dài thực tế sau khi áp dụng tốc độ video (config)
                dur = round(r['duration'] / config.get('video_speed', 1.0), 1)
                desc = r['description'] or ""
                usage = r['usage_count']
                
                broll_data[v] = {
                    'usage_count': usage, 
                    'keep_audio': bool(r['keep_audio']), 
                    'duration': r['duration'], 
                    'description': desc
                }
                broll_usage[v] = usage
                broll_text += f"- File: '{v}' (Dài {dur}s) | Đã dùng: {usage} lần | Mô tả: {desc}\n"

            # =======================================================
            # 4. GỌI AI ĐẠO DIỄN (Lên kịch bản cắt ghép)
            # =======================================================
            opening_state = {"lock": self.opening_lock, "used": self.used_opening_videos}
            broll_state = {"lock": self.broll_lock, "used": self.used_broll_videos}
            timeline = get_director_timeline(
                voice_text,
                broll_text,
                config,
                self.add_log,
                voice_name,
                proj_context,
                opening_state=opening_state,
                global_broll_state=broll_state,
                broll_usage=broll_usage,
            )
            
            # =======================================================
            # 5. RENDER VIDEO & GHI JOB SHOPEE (DATABASE)
            # =======================================================
            from shopee_export import export_rendered_video_to_shopee_files, is_shopee_out_of_stock_project
            
            # Hàm render giờ đây sẽ trả về danh sách chính xác các file Broll nó đã dùng
            if is_video_voice:
                actual_used_brolls = render_faceless_video_with_base(
                    voice_name, voice_path, timeline, proj_dir, proj_name,
                    config, out_file, GLOBAL_OUT_DIR, self.add_log, broll_data
                )
            else:
                actual_used_brolls = render_faceless_video(
                    voice_name, voice_path, timeline, proj_dir, proj_name,
                    config, out_file, GLOBAL_OUT_DIR, self.add_log, broll_data
                )

            speed_val = config.get("video_speed", 1.0)
            out_file = apply_video_speed_after_render(out_file, speed_val, self.add_log)
            
            # Kiểm tra xem project có đang bật "Hết hàng" không để quyết định ghi job Shopee
            shopee_out_of_stock = is_shopee_out_of_stock_project(proj_dir)
            if shopee_out_of_stock:
                self.add_log(f"[{voice_name}] ⏭️ Shopee đang để Hết hàng, bỏ qua lưu Job đăng bài.")
            else:
                exported_to_shopee, _ = export_rendered_video_to_shopee_files(proj_dir, out_file, config=config, default_status="Chưa đăng")
                if exported_to_shopee:
                    self.add_log(f"[{voice_name}] ✅ Đã lưu Job đăng Shopee vào Database.")

            with self.completed_lock:
                self.completed_count += 1
            self.add_log(f"✅ THÀNH CÔNG: Đã xuất xưởng {voice_name}!")

            # =======================================================
            # 6. GHI NHẬT KÝ VIDEO THÀNH PHẨM VÀO DATABASE (Thay CSV cũ)
            # =======================================================
            try:
                database.log_rendered_video(proj_name, voice_name, out_file)
            except Exception as e:
                self.add_log(f"⚠️ Không ghi được log video vào DB: {e}")

            # =======================================================
            # 7. CỘNG ĐIỂM SỬ DỤNG (UPDATE DATABASE SIÊU TỐC)
            # =======================================================
            try:
                with database.db_lock:
                    conn = database.get_connection()
                    cursor = conn.cursor()
                    # Cộng 1 lượt dùng cho file Voice + ghi dấu thời gian dùng (cooldown 3 ngày)
                    cursor.execute("""
                        UPDATE voices 
                        SET usage_count = usage_count + 1,
                            last_used = datetime('now', 'localtime')
                        WHERE project_id = ? AND file_name = ?
                    """, (db_proj_id, voice_name))
                    
                    # Cộng 1 lượt dùng cho từng cảnh trám thực tế đã xuất hiện trong video
                    if actual_used_brolls:
                        for v_name in actual_used_brolls:
                            cursor.execute("UPDATE brolls SET usage_count = usage_count + 1 WHERE project_id = ? AND file_name = ?", (db_proj_id, v_name))
                    
                    conn.commit()
                    conn.close()
                
                # Cập nhật lại giao diện Tab 1 để sếp thấy điểm nhảy ngay lập tức
                self.main_app.root.after(0, self.main_app.tab1.load_voices)
                if self.main_app.tab1.current_project_id == pid:
                    self.main_app.root.after(0, lambda: self.main_app.tab1.render_video_list())
            except Exception as e:
                self.add_log(f"⚠️ Lỗi cập nhật Database số lần dùng: {e}")
            finally:
                try:
                    conn.close()
                except:
                    pass

            return True

        except Exception as e:
            self.add_log(f"❌ LỖI NGHIÊM TRỌNG {voice_name}: {e}")
            return False
