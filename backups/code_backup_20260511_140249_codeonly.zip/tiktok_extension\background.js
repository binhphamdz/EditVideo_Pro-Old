const APP_ID = "editvideo_pro_tiktok_agent_v1";
const DEFAULT_WS_PORTS = Array.from({ length: 21 }, (_, index) => 8765 + index);
const SHOWCASE_URL = "https://shop.tiktok.com/streamer/showcase/product/list";
const UPLOAD_URL = "https://www.tiktok.com/tiktokstudio/upload";
const RETRY_MS = 3000;

let ws = null;
let connecting = false;
let receiverId = "";
let portIndex = 0;
let candidateUrls = [];

function wakeAndConnect() {
  ensureReceiverId(() => {
    sendHello();
    connect();
  });
}

function buildCandidateUrls(savedUrl) {
  const urls = [];
  if (savedUrl) urls.push(savedUrl);
  for (const port of DEFAULT_WS_PORTS) urls.push(`ws://127.0.0.1:${port}`);
  return Array.from(new Set(urls));
}

function ensureReceiverId(callback) {
  chrome.storage.local.get(["receiverId"], (result) => {
    receiverId = (result.receiverId || "").trim();
    if (!receiverId) {
      receiverId = "chrome-" + Math.random().toString(36).slice(2, 8);
      chrome.storage.local.set({ receiverId }, () => callback(receiverId));
      return;
    }
    callback(receiverId);
  });
}

function sendHello() {
  if (ws && ws.readyState === WebSocket.OPEN && receiverId) {
    ws.send(JSON.stringify({ type: "hello", appId: APP_ID, receiver: receiverId, extensionId: chrome.runtime.id }));
  }
}

function sendWs(payload) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ appId: APP_ID, receiver: receiverId, ...payload }));
  }
}

function connect() {
  if (connecting || (ws && ws.readyState === WebSocket.OPEN)) return;
  connecting = true;
  chrome.storage.local.get(["wsUrl"], (result) => {
    candidateUrls = buildCandidateUrls((result.wsUrl || "").trim());
    const wsUrl = candidateUrls[portIndex % candidateUrls.length];
    console.log("[EditVideo Pro Agent] connecting", wsUrl);
    try {
      ws = new WebSocket(wsUrl);
    } catch {
      connecting = false;
      portIndex += 1;
      setTimeout(connect, RETRY_MS);
      return;
    }

    ws.addEventListener("open", () => {
      connecting = false;
      console.log("[EditVideo Pro Agent] connected", wsUrl, receiverId);
      sendHello();
    });
    ws.addEventListener("message", (event) => handleServerMessage(event.data));
    ws.addEventListener("close", () => {
      connecting = false;
      portIndex += 1;
      setTimeout(connect, RETRY_MS);
    });
    ws.addEventListener("error", () => {
      try { ws.close(); } catch {}
    });
  });
}

function parsePayload(raw) {
  try {
    const data = JSON.parse(raw);
    return {
      type: data.type || "fill_product",
      appId: data.appId || data.app_id || "",
      url: data.url || data.product_url || "",
      caption: data.caption || "",
      requestId: data.requestId || data.request_id || "",
      target: data.target || data.receiver_id || "",
    };
  } catch {
    return { type: "", appId: "", url: "", caption: "", requestId: "", target: "" };
  }
}

function handleServerMessage(raw) {
  const payload = parsePayload(raw);
  if (payload.appId && payload.appId !== APP_ID) return;
  if (payload.target && payload.target !== receiverId) return;
  if (!payload.requestId) return;

  if (payload.url) openShowcaseAndSend(payload);
}

function openShowcaseAndSend(payload) {
  chrome.tabs.query({ url: SHOWCASE_URL + "*" }, (tabs) => {
    const tab = tabs && tabs.length ? tabs[0] : null;
    if (tab && tab.id) {
      chrome.tabs.update(tab.id, { active: true }, () => sendToContent(tab.id, "fill_product", payload));
      return;
    }
    chrome.tabs.create({ url: SHOWCASE_URL, active: true }, (createdTab) => {
      if (createdTab && createdTab.id) waitAndSend(createdTab.id, "fill_product", payload, SHOWCASE_URL, 40);
    });
  });
}

function waitAndSend(tabId, type, payload, urlPrefix, triesLeft) {
  if (triesLeft <= 0) {
    reportFinal(payload.requestId, false, `Không mở được tab ${urlPrefix}`);
    return;
  }
  chrome.tabs.get(tabId, (tab) => {
    if (!tab || !tab.url || !tab.url.startsWith(urlPrefix)) {
      setTimeout(() => waitAndSend(tabId, type, payload, urlPrefix, triesLeft - 1), 500);
      return;
    }
    sendToContent(tabId, type, payload, () => {
      setTimeout(() => waitAndSend(tabId, type, payload, urlPrefix, triesLeft - 1), 500);
    });
  });
}

function sendToContent(tabId, type, payload, onFail) {
  chrome.tabs.sendMessage(tabId, { type, url: payload.url, requestId: payload.requestId, caption: payload.caption }, () => {
    if (!chrome.runtime.lastError) return;
    chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
      if (chrome.runtime.lastError) {
        if (onFail) onFail();
        return;
      }
      chrome.tabs.sendMessage(tabId, { type, url: payload.url, requestId: payload.requestId, caption: payload.caption }, () => {
        if (chrome.runtime.lastError && onFail) onFail();
      });
    });
  });
}

function reportLinkDone(requestId, url, ok) {
  sendWs({ type: "link_done", requestId, url, ok });
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message) return;
  if (message.type === "link_done") {
    reportLinkDone(message.requestId || "", message.url || "", Boolean(message.ok));
  }
});

ensureReceiverId(connect);
setInterval(sendHello, 5000);
setInterval(wakeAndConnect, 15000);

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("editvideo-pro-agent-keepalive", { periodInMinutes: 0.5 });
  wakeAndConnect();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("editvideo-pro-agent-keepalive", { periodInMinutes: 0.5 });
  wakeAndConnect();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "editvideo-pro-agent-keepalive") {
    wakeAndConnect();
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && (tab.url.startsWith(SHOWCASE_URL) || tab.url.startsWith(UPLOAD_URL))) {
    wakeAndConnect();
  }
});

chrome.tabs.onActivated.addListener(() => wakeAndConnect());

chrome.alarms.create("editvideo-pro-agent-keepalive", { periodInMinutes: 0.5 });
wakeAndConnect();
